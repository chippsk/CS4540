/*************************************************
* Course: CS 4540 – Fall 2014
* Assignment 2 - Problem 1
* Name: Kyle Chipps
* E-mail: kyle.d.chipps@wmich.edu
* Submitted: 10/15/14
/************************************************* 

This project takes a string and changes the case of that string and returns 
it.  It does this by using two pipes to communicate.  To make the program, 
in this directory, type "make".  Then in the P1A2 directory, a binary is
made which you can run.    
