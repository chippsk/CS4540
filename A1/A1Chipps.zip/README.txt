This is Kyle Chipps's Assignment 1 Proejct
Using my makefile the project compiles and produces the 
correct results on ubuntu 14.04, debian wheezy 7.2 and 
fedora 20.  So if you have any problems, please contact 

kyle.d.chipps@wmich.edu

Otherwise to get all the executables, just from this 
directory run "make".  The executables will be in the same 
directory as the source files.  

"Make clean" will delete all executables and object files.
