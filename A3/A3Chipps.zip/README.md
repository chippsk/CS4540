

/*************************************************

    Course: CS 4540 – Fall 2014
    Assignment 3 - Problem 1
    Name: Kyle Chipps
    E-mail: kyle.d.chipps@wmich.edu
    Submitted:  /*************************************************

This program takes input from the user in the form of a list of integers.  
Then it spins up threads that compute the average, minimum and maximum.  
To create the binary, in the AS3 directory type "make".
Then move the P1A3 directory and run q1.out.

